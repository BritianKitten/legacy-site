<?php

?>
<head>
	<title>Britain Kitten - Writing</title>
	<link rel='stylesheet' type='text/css' href='britaink.css' />
	<meta name="description" content="Britain Kitten - Writing" />
	<meta name="keywords" content="britain kitten writing" />
</head>
<body>
	<div id='wstuff'>
		<div id='menuBar'>
			<?php include 'menuBar.php' ?>
		</div>
	<div class='leftText'>
		
	</div>
	<div class='rightStuff'>
		<div class='writing'>
	<br/><br/><br/>
	<br/><br/><br/>
		Miss Britain Kitten does<br/>
		freelance writing and is<br/>
		currently working on her own<br/>
		book which will be introduced<br/>
		to the world through an<br/>
		explosive art exhibition in<br/>
		London late 2013.<br/><br/>
		The works of art, combining<br/>
		taxidermy, found objects and<br/>
		illustrations, will be <br/>
		photographed and used to<br/>
		illustrate and inspire the<br/>
		writing. Sample writing is<br/>
		planned to be available on the <br/>
		site soon.
	</div>
	</div>
	<div class='fc'></div>
	</div>
</body>