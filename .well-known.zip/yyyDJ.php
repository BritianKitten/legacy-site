<?php

?>
<head>
	<title>Britain Kitten - Contact Me!</title>
	<link rel='stylesheet' type='text/css' href='britaink.css' />
	<meta name="description" content="Britain Kitten - DJ" />
	<meta name="keywords" content="britain kitten DJ" />
</head>
<body>
	<div id='djstuff'>
		<div id='menuBar'>
			<?php include 'menuBar.php' ?>
		</div>
	<div class='leftText'>
		<br/><strong>DJ</strong><br/><br/>
		Miss Britain Kitten also likes to indulge in DJing in the London Alternative scene, playing a fantastic cocktail of industrial, EBM, Goth, 80�s and rock.<br/><br/>
		She runs Asylum club night in the Intrepid Fox in Soho, London WC2H every second Sunday of the month, 8pm to 11pm.<br/><br/>
		Miss Britain Kitten guest DJs at various alternative venues in London and also once co-ran Plus One Club and Club Distraction.<br/><br/>
		When Miss Britain Kitten DJs there is the added bonus of having the DJ in six inch stilettos...<br/><br/> So <a href='contact.php'>get in touch</a> if you are interested in her being a guest DJ at your event!
		</div>
	<div class='rightStuff'>
		<div class='picHolder'>
			<img src='images/dj.jpg' title='DJ Kitten' alt='DJ Kitten' />
		</div>
	</div>
	<div class='fc'></div>
	</div>
</body>