<?php

?>
<head>
	<link rel='stylesheet' type='text/css' href='britaink.css' />
	<meta name="description" content="Britain Kitten" />
	<meta name="keywords" content="britain kitten burlesque art" />
</head>
<body>
	<div id='home'>
		<div id='menuBar'>
			<?php include 'menuBar.php' ?>
		</div>
	</div>
</body>