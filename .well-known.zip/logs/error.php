#
#<?php die('Forbidden.'); ?>
#Date: 2015-12-02 19:31:08 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2015-12-02T19:31:08+00:00	INFO 92.3.210.191	joomlafailure	Username and password do not match or you do not have an account yet.
2016-01-01T18:29:36+00:00	INFO 94.44.253.110	joomlafailure	Username and password do not match or you do not have an account yet.
